"""
< ALY 6140 GROUP 3 , Capstone project lib >

Written by Tianyu Zhang, Linke Yuan

# This is a Python script that contains 3 functions to support Group 4's Capstone Project 
Jupyter Notebook presentation

"""
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
# read the dataset
df = pd.read_csv('C:/Users/张天羽/Desktop/assigned work heart diseases.CSV')
# display the first few rows of the dataset
df.head()

# Define Function 1
# convert 'Yes' and 'No' to 1 and 0, respectively
df['HeartDisease'] = df['HeartDisease'].map({'Yes': 1, 'No': 0})


def plot_heart_disease_by_age(df):
    '''
    This function generates a bar plot showing the number of people with heart disease grouped by age 
    category. It filters the DataFrame df to include only instances where 'HeartDisease' is equal to 1. 
    It then groups the data by 'AgeCategory' and counts the occurrences of heart disease in each category. 
    The function plots the data using matplotlib.pyplot and highlights the age category with the highest 
    count by adding a red dashed line.
    '''
    heart_disease_df = df[df['HeartDisease'] == 1].groupby('AgeCategory')['HeartDisease'].count().sort_values(ascending=False)
    highest_group = heart_disease_df.index[0]

    fig, ax = plt.subplots(figsize=(10, 5))
    heart_disease_df.plot(kind='bar', ax=ax)
    ax.set_xticklabels(heart_disease_df.index, rotation=45, ha='right')

    plt.title('Number of People with Heart Disease by Age Category')
    plt.xlabel('Age Category')
    plt.ylabel('Number of People with Heart Disease')

    # highlight the age category with the highest count
    plt.axvline(x=highest_group, color='red', linestyle='--')
    plt.show()
plot_heart_disease_by_age(df)   

 
# Define Function 2
categorical_features = ['Smoking', 'AlcoholDrinking', 'Stroke', 'PhysicalHealth', 'MentalHealth', 'DiffWalking', 'Sex', 'AgeCategory', 'Race', 'Diabetic', 'PhysicalActivity', 'GenHealth', 'SleepTime', 'Asthma', 'KidneyDisease', 'SkinCancer']
def categorical_feature_func():
  '''
  This function creates multiple count plots for categorical features in the DataFrame df. It uses 
  seaborn.countplot to display the count of instances for each category, colored by the 'HeartDisease' 
  feature. The function iterates over the categorical_features list and plots each feature in a separate
  subplot.
  '''
  i = 1
  plt.figure(figsize = (30,50))
  for feature in categorical_features:
      plt.subplot(5,5,i)
      sns.set(palette='Paired')
      sns.set_style("ticks")
      ax = sns.countplot(x = feature, data = df, hue = 'HeartDisease')
      ax.set_xticklabels(ax.get_xticklabels(), rotation=45, ha="right")
      i +=1

categorical_feature_func()


# Define Function 3
# 1. Handle categorical data
# Define 2 array contain features are categorical type(include Heart Disease feature) 
# and numeric type
'''
Categorical Data Handling: The code identifies categorical features in df and creates a new DataFrame
 df_cat containing only these features. It then uses sklearn.preprocessing.OrdinalEncoder to encode the
 categorical features into numeric values.
'''
cat_features = []
num_features = []
for column, i in zip(df.columns, df.dtypes):
    if i == object:
        cat_features.append(column)
    else:
        num_features.append(column)
df_cat = df[cat_features].copy()
# Ordinal Encoder
from sklearn.preprocessing import OrdinalEncoder

ordinal_encoder = OrdinalEncoder()
df_cat_encoded = ordinal_encoder.fit_transform(df_cat)
df_cat_encoded = pd.DataFrame(df_cat_encoded, columns = cat_features)


# OrdinalEncoderconvert categorical to numeric
'''
Numeric Data Handling: The code creates a DataFrame df_num containing only the numeric features from 
df. It performs standardization using sklearn.preprocessing.StandardScaler to scale the numeric features.
'''

#  merge new dataframe with numeric feature to create new numeric dataframe
df_numeric = pd.merge(df_cat_encoded, df[num_features],left_index=True, right_index=True)
# Handle numeric data
# Standardization
from sklearn.preprocessing import StandardScaler
stand_scale = StandardScaler()
df_num = df[num_features].copy()
df_num_scaler = stand_scale.fit_transform(df_num)
df_num_scaler = pd.DataFrame(df_num_scaler, columns = num_features)
df_num_scaler

'''
Merging DataFrames: The code merges the encoded categorical data (df_cat_encoded) with the scaled 
numeric data (df_num_scaler) to create a new DataFrame df_new that contains both scaled and encoded 
features.
'''
df_numeric_scaler = pd.merge(df_cat_encoded, df_num_scaler,left_index=True, right_index=True)
# create new dataframe that already scale and convert categorical to numeric
df_new = df_numeric_scaler.copy()


def draw_scatter_3D(feature1, feature2, feature3):
    '''
    This function generates a 3D scatter plot. It takes three feature names as input and creates a scatter
     plot where the x, y, and z axes represent the provided features. The points in the plot are colored
     based on the 'HeartDisease' feature. In the provided example, the function is called with "SleepTime",
     "BMI", and "PhysicalHealth" as the three features.
    '''
    fig = plt.figure(figsize=(20,10))
    axes = plt.axes(projection='3d')

    axes.scatter3D(df_new[feature1], df_new[feature2], df_new[feature3], c=df_new["HeartDisease"])

    axes.set_xlabel(feature1)
    axes.set_ylabel(feature2)
    axes.set_zlabel(feature3)

    fig.tight_layout()
    plt.show()

draw_scatter_3D("SleepTime", "BMI", "PhysicalHealth")



